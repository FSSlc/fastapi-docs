# ChatApp


# To create client use command below:
# npx @openapitools/openapi-generator-cli generate -i openapi.json -g python -o client

# To run the server type this:
# uvicorn main:app --reload
