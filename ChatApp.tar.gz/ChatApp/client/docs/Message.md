# Message


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msg_content** | **str** |  | 
**from_usr** | **int** |  | 
**id** | **int** |  | 
**to_usr** | **int** |  | 
**date** | **datetime** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


