""" All built-in endpoints """
from .login import LoginEndpoint
from .logout import LogoutEndpoint
from .register import RegisterEndpoint
from .confirm import ConfirmEndpoint
